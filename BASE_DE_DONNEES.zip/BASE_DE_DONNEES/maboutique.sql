-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : mar. 08 juil. 2025 à 14:07
-- Version du serveur : 5.7.24
-- Version de PHP : 8.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `maboutique`
--

-- --------------------------------------------------------

--
-- Structure de la table `adresse`
--

CREATE TABLE `adresse` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postal` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `adresse`
--

INSERT INTO `adresse` (`id`, `user_id`, `firstname`, `lastname`, `adresse`, `postal`, `city`, `country`, `phone`) VALUES
(8, 2, 'Adama', 'DIAWARA', '20 Rue de Cuques', '13100', 'AIX-EN-PROVENCE', 'FR', '0606060606'),
(9, 2, 'Adama', 'DIAWARA', '4 RUE GUSTAVE DESPLACES', '13100', 'AIX-EN-PROVENCE', 'FR', '0606060606'),
(10, 2, 'Adama', 'DIAWARA', '5 AV. DE L\'ABBE ROGER DERRY', '94400', 'Vitry-sur-Seine', 'FR', '0606060606');

-- --------------------------------------------------------

--
-- Structure de la table `carrier`
--

CREATE TABLE `carrier` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `carrier`
--

INSERT INTO `carrier` (`id`, `name`, `description`, `price`) VALUES
(1, 'Colissimo', 'Fiable, rapide et sécurisé\r\nMax : 5 jours\r\nPartout en France', 3.9),
(2, 'Chronopost', 'Fiable, rapide et sécurisé\r\nMax : 2 jours\r\nPartout en France', 4.9),
(3, 'DHL', 'Fiable, rapide et sécurisé\r\nMax : 1 jours\r\nPartout en France', 5.9),
(4, 'GLS', 'Fiable, rapide et sécurisé\r\nMax : 10 jours\r\nPartout en France', 2.5);

-- --------------------------------------------------------

--
-- Structure de la table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `category`
--

INSERT INTO `category` (`id`, `name`, `slug`) VALUES
(2, 'MacBook', 'macbook'),
(3, 'SmartPhone', 'smartphone'),
(4, 'Montre connectée', 'montre-connectee'),
(5, 'Ordinateur portable', 'ordinateur-portable'),
(6, 'Tablette', 'tablette'),
(7, 'iPhone', 'iphone');

-- --------------------------------------------------------

--
-- Structure de la table `doctrine_migration_versions`
--

CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `doctrine_migration_versions`
--

INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
('DoctrineMigrations\\Version20250706235851', '2025-07-06 23:59:06', 1213);

-- --------------------------------------------------------

--
-- Structure de la table `header`
--

CREATE TABLE `header` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `button_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `button_link` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `illustration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `messenger_messages`
--

CREATE TABLE `messenger_messages` (
  `id` bigint(20) NOT NULL,
  `body` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `headers` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue_name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `available_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `delivered_at` datetime DEFAULT NULL COMMENT '(DC2Type:datetime_immutable)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `order`
--

CREATE TABLE `order` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `carrier_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `carrier_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `carrier_price` double NOT NULL,
  `delivry` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` int(11) NOT NULL,
  `stripe_session_id` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `order`
--

INSERT INTO `order` (`id`, `user_id`, `carrier_id`, `created_at`, `carrier_name`, `carrier_price`, `delivry`, `state`, `stripe_session_id`) VALUES
(1, 2, NULL, '2025-07-07 05:21:01', 'Colissimo', 3.9, 'Adama DIAWARA<br/>20 Rue de Cuques<br/>13100, AIX-EN-PROVENCE<br/>FR<br/>0606060606', 2, 'cs_test_b1fVOlJb8pH0p1HDR7jrbl88stCj9Aqdr4Jx2QCByMT1d8gFLLuPtbHGPj'),
(2, 2, NULL, '2025-07-07 05:41:35', 'Colissimo', 3.9, 'Adama DIAWARA<br/>20 Rue de Cuques<br/>13100, AIX-EN-PROVENCE<br/>FR<br/>0606060606', 1, NULL),
(3, 2, NULL, '2025-07-07 05:41:36', 'Colissimo', 3.9, 'Adama DIAWARA<br/>20 Rue de Cuques<br/>13100, AIX-EN-PROVENCE<br/>FR<br/>0606060606', 1, NULL),
(4, 2, NULL, '2025-07-07 05:43:03', 'Colissimo', 3.9, 'Adama DIAWARA<br/>20 Rue de Cuques<br/>13100, AIX-EN-PROVENCE<br/>FR<br/>0606060606', 1, NULL),
(5, 2, NULL, '2025-07-07 05:45:00', 'Colissimo', 3.9, 'Adama DIAWARA<br/>20 Rue de Cuques<br/>13100, AIX-EN-PROVENCE<br/>FR<br/>0606060606', 1, NULL),
(6, 2, NULL, '2025-07-07 05:45:51', 'Colissimo', 3.9, 'Adama DIAWARA<br/>20 Rue de Cuques<br/>13100, AIX-EN-PROVENCE<br/>FR<br/>0606060606', 1, NULL),
(7, 2, NULL, '2025-07-07 05:46:44', 'Colissimo', 3.9, 'Adama DIAWARA<br/>20 Rue de Cuques<br/>13100, AIX-EN-PROVENCE<br/>FR<br/>0606060606', 1, NULL),
(8, 2, NULL, '2025-07-07 10:56:16', 'Chronopost', 4.9, 'Adama DIAWARA<br/>4 RUE GUSTAVE DESPLACES<br/>13100, AIX-EN-PROVENCE<br/>FR<br/>0606060606', 2, 'cs_test_b13gSIuTNvfHRSjhIXLwEMsI7SBtcXHx3wfW3IID7IQf3qFTlujNDheQLp'),
(9, 2, NULL, '2025-07-07 14:03:41', 'Colissimo', 3.9, 'Adama DIAWARA<br/>20 Rue de Cuques<br/>13100, AIX-EN-PROVENCE<br/>FR<br/>0606060606', 2, 'cs_test_b1WD10dHwX5smpRJ8YsDvX72jblgFmIWrUYdE5zCZbQhZBejze5q3XDQw9'),
(10, 2, NULL, '2025-07-08 00:02:28', 'GLS', 2.5, 'Adama DIAWARA<br/>20 Rue de Cuques<br/>13100, AIX-EN-PROVENCE<br/>FR<br/>0606060606', 2, 'cs_test_b1cuv6vB6pNBV8vhKe3wjkqIBrhYHqPm5Y1dusvCfpOGBdboaK7rPWHeAS');

-- --------------------------------------------------------

--
-- Structure de la table `order_detail`
--

CREATE TABLE `order_detail` (
  `id` int(11) NOT NULL,
  `my_order_id` int(11) DEFAULT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_illustration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `product_price` double NOT NULL,
  `product_tva` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `order_detail`
--

INSERT INTO `order_detail` (`id`, `my_order_id`, `product_name`, `product_illustration`, `product_quantity`, `product_price`, `product_tva`) VALUES
(1, 1, 'MacBook', '2025-07-07-43785d559eba125a980fdf9199c2455f2e1fe001.jpg', 1, 1750, 20),
(2, 2, 'MacBook', '2025-07-07-43785d559eba125a980fdf9199c2455f2e1fe001.jpg', 1, 1750, 20),
(3, 3, 'MacBook', '2025-07-07-43785d559eba125a980fdf9199c2455f2e1fe001.jpg', 1, 1750, 20),
(4, 4, 'MacBook', '2025-07-07-43785d559eba125a980fdf9199c2455f2e1fe001.jpg', 1, 1750, 20),
(5, 5, 'MacBook', '2025-07-07-43785d559eba125a980fdf9199c2455f2e1fe001.jpg', 1, 1750, 20),
(6, 6, 'MacBook', '2025-07-07-43785d559eba125a980fdf9199c2455f2e1fe001.jpg', 1, 1750, 20),
(7, 7, 'MacBook', '2025-07-07-43785d559eba125a980fdf9199c2455f2e1fe001.jpg', 1, 1750, 20),
(8, 8, 'MacBook', '2025-07-07-43785d559eba125a980fdf9199c2455f2e1fe001.jpg', 1, 1750, 20),
(9, 9, 'MacBook', '2025-07-07-43785d559eba125a980fdf9199c2455f2e1fe001.jpg', 1, 1750, 20),
(10, 10, 'Iphone', '2025-07-07-721e91680ac15bad8a50b90dd3fcd250bb9e45b0.jpg', 1, 890.99, 20),
(11, 10, 'iPhone 15', '2025-07-07-748a499dfd2c63cb00dc6452a2ce390e4492eebf.jpg', 1, 900, 20);

-- --------------------------------------------------------

--
-- Structure de la table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `illustration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `tva` double NOT NULL,
  `in_homepage` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `product`
--

INSERT INTO `product` (`id`, `category_id`, `product_id`, `name`, `slug`, `description`, `illustration`, `price`, `tva`, `in_homepage`) VALUES
(1, 2, NULL, 'McBook', 'macbk', '<div><strong>Écran</strong> : 13,6 pouces Liquid Retina (2560 x 1664)</div><div><strong>Processeur</strong> : Apple M2 (8 cœurs CPU, 8 ou 10 cœurs GPU)</div><div><strong>Mémoire vive (RAM)</strong> : 8 Go (jusqu’à 24 Go)</div><div><strong>Stockage</strong> : SSD de 256 Go (jusqu’à 2 To)</div><div><strong>Autonomie</strong> : Jusqu’à 18 heures<br><br><br></div>', '2025-07-08-b858fce604a855964ea59a4b9476a1b4381c943f.jpg', 1750, 20, 0),
(2, 4, NULL, 'Montre', 'montre-connectee', '<div>&nbsp;Montre connectée élégante et légère, idéale pour le suivi de votre activité au quotidien.<br>&nbsp;Suivi du rythme cardiaque, notifications en temps réel et autonomie longue durée.<br>&nbsp;Compatible iOS et Android via Bluetooth.&nbsp;</div>', '2025-07-08-5fae4279a43d86b1332e9306abb587cbfcd6b331.jpg', 87.9, 20, 0),
(3, 5, NULL, 'ASUS', 'asus', '<div>&nbsp;PC portable ASUS puissant et polyvalent, idéal pour le travail et le divertissement.<br>&nbsp;Écran Full HD, processeur rapide et grande autonomie pour une productivité optimale.<br>&nbsp;Design fin, léger et robuste, parfait pour une utilisation quotidienne.&nbsp;</div>', '2025-07-08-f5ae64a37316d1e009958e47554580b10f3abb32.jpg', 12000, 20, 0),
(4, 6, NULL, 'Tablette', 'tablette-1', '<div>&nbsp;Tablette tactile performante, idéale pour le multimédia, la lecture et la navigation web.<br>&nbsp;Écran HD, processeur fluide et grande autonomie pour un usage quotidien.<br>&nbsp;Compatible avec les applications Android ou iOS selon le modèle.&nbsp;</div>', '2025-07-08-644775af6ca898c1513a9f0ed5b422f29f915767.jpg', 500, 20, 0),
(5, 3, NULL, 'Smartphone', 'smartphone', '<div>&nbsp;Smartphone moderne avec écran haute résolution et appareil photo performant.<br>&nbsp;Navigation fluide, grande autonomie et design élégant.<br>&nbsp;Idéal pour un usage quotidien, pro ou multimédia.&nbsp;</div>', '2025-07-08-6cd10a04e2682ba35bff799575f33310ab840d48.jpg', 700, 20, 0),
(6, 7, NULL, 'Iphone', 'iphone-1', '<div>&nbsp;<strong>iPhone 16</strong> avec design raffiné, écran Super Retina XDR et puce A18 ultra-performante.<br> Système photo avancé pour des clichés pro de jour comme de nuit.<br> Autonomie améliorée, iOS 18, 5G et sécurité renforcée avec Face ID.&nbsp;</div>', '2025-07-08-57a460710fc3e8098cfe9f6ab88bf15731b4d7a5.jpg', 890.99, 20, 0),
(7, 5, NULL, 'Ordinateur portable', 'ordinateur-portable-1', '<div>&nbsp;Ordinateur portable performant avec processeur Intel Core<strong> i7</strong>, 16 Go de RAM et <strong>SSD 512 Go</strong>.&nbsp;<br>Idéal pour le multitâche, la bureautique avancée et le développement.<br> Écran Full HD de 15,6 pouces pour un confort visuel optimal.&nbsp;</div>', '2025-07-08-4c4169cea978bfbcd399e76eda8b1c3fbcae9ce9.jpg', 450, 20, 0),
(8, 5, NULL, 'Ordinateur portable mutitache', 'ordinateur-portable-mutitache-1', '<div>&nbsp;Ordinateur portable performant avec processeur Intel <strong>Core i7,</strong> 32<strong> Go</strong> de RAM et SSD 1<strong>To</strong>.&nbsp;<br>Idéal pour le multitâche, la bureautique avancée et le développement.&nbsp;<br>Écran Full HD de 15,6 pouces pour un confort visuel optimal.&nbsp;</div>', '2025-07-08-66bb8f82b946285190f912ad8fb0438bddd81915.jpg', 700, 20, 0),
(9, 5, NULL, 'Ordinateur portable', 'ordinateur-portable-2', '<div>&nbsp;Ordinateur portable performant avec processeur Intel <strong>Core i5,</strong> 8<strong> Go</strong> de RAM et <strong>SSD 250 Go</strong>.&nbsp;<br>Idéal pour le multitâche, la bureautique avancée et le développement.&nbsp;<br>Écran Full HD de 15,6 pouces pour un confort visuel optimal.&nbsp;</div>', '2025-07-08-445626b37e8dcfccd368da62497be43dc619916d.jpg', 350, 20, 0),
(10, 5, NULL, 'Ordinateur portable', 'ordinateur-portable-3', '<div>&nbsp;Ordinateur portable performant avec processeur Intel <strong>Core i7,</strong> 32<strong> Go</strong> de RAM et SSD 2<strong>To</strong>.&nbsp;<br>Idéal pour le multitâche, la bureautique avancée et le développement.&nbsp;<br>Écran Full HD de 15,6 pouces pour un confort visuel optimal.&nbsp;</div>', '2025-07-08-4713760f173bda91db4a8da6f2102c2e05681612.jpg', 950, 20, 0),
(11, 5, NULL, 'Ordinateur portable', 'ordinateur-portable-4', '<div>&nbsp;Ordinateur portable performant avec processeur Intel <strong>Core i7,</strong> 32<strong> Go</strong> de RAM et SSD 1<strong>To</strong>.&nbsp;<br>Idéal pour le multitâche, la bureautique avancée et le développement.&nbsp;<br>Écran Full HD de 15,6 pouces pour un confort visuel optimal.&nbsp;</div>', '2025-07-08-d111e4978c5142550c80b62317d8726f43f5df12.jpg', 750, 20, 0),
(12, 2, NULL, 'MacBook M1', 'macbook-3', '<div>&nbsp;MacBook élégant et puissant avec puce Apple <strong>M1</strong>, <strong>8 Go</strong> de RAM et SSD <strong>256 Go</strong>.&nbsp;<br>Excellente autonomie et fluidité pour le travail, la création et la navigation.<br> Écran Retina 13\" offrant une qualité d’image exceptionnelle.&nbsp;</div>', '2025-07-08-46f0de5aaf557a842fbb268ded773f0e2c79bec7.jpg', 1300, 20, 0),
(13, 2, NULL, 'MacBook', 'macbook-2', '<div>&nbsp;MacBook élégant et puissant avec puce Apple <strong>M1</strong>, <strong>8 Go</strong> de RAM et SSD <strong>256 Go</strong>.&nbsp;<br>Excellente autonomie et fluidité pour le travail, la création et la navigation.<br>Écran Retina 13\" offrant une qualité d’image exceptionnelle.&nbsp;</div>', '2025-07-08-20131c5699c13916b7b4d4506768aa6659b7b6b0.jpg', 950, 20, 0),
(14, 2, NULL, 'MacBook', 'macbook-4', '<div>&nbsp;MacBook élégant et puissant avec puce Apple <strong>M1</strong>, <strong>16 Go</strong> de RAM et SSD <strong>512 Go</strong>.&nbsp;<br>Excellente autonomie et fluidité pour le travail, la création et la navigation.<br>Écran Retina 13\" offrant une qualité d’image exceptionnelle.&nbsp;</div>', '2025-07-08-70d6e0728e2beabc3bb1d672b3ed5396c338d4b0.jpg', 1500, 20, 0),
(15, 2, NULL, 'MacBook', 'macbook-5', '<div>&nbsp;MacBook élégant et puissant avec puce Apple <strong>M1</strong>, <strong>32 Go</strong> de RAM et SSD <strong>1To</strong>.&nbsp;<br>Excellente autonomie et fluidité pour le travail, la création et la navigation.<br>Écran Retina 13\" offrant une qualité d’image exceptionnelle.&nbsp;</div>', '2025-07-08-7b65a2dd3ead02f0e1c3585a110bbe6165510f47.jpg', 2700, 20, 0),
(16, 2, NULL, 'MacBook', 'macbook-6', '<div>&nbsp;MacBook élégant et puissant avec puce Apple <strong>M1</strong>, <strong>8 Go</strong> de RAM et SSD <strong>256 Go</strong>.&nbsp;<br>Excellente autonomie et fluidité pour le travail, la création et la navigation.<br>Écran Retina 13\" offrant une qualité d’image exceptionnelle.&nbsp;</div>', '2025-07-08-5497409873bc53ba9ef2dea382ad8a56a506fd57.jpg', 1000, 20, 0),
(17, 2, NULL, 'MacBook-7', 'macbook', '<div>MacBook élégant et puissant avec puce Apple <strong>M1</strong>, 16<strong> Go</strong> de RAM et SSD <strong>256 Go</strong>.&nbsp;<br>Excellente autonomie et fluidité pour le travail, la création et la navigation.<br>Écran Retina 13\" offrant une qualité d’image exceptionnelle.&nbsp;</div>', '2025-07-08-f5c807ebfedc04f8b94bfa477e37e61053a93562.jpg', 1000, 20, 0),
(18, 2, NULL, 'MacBook', 'macbook-8', '<div>&nbsp;MacBook élégant et puissant avec puce Apple <strong>M1</strong>, <strong>8 Go</strong> de RAM et SSD <strong>512 Go</strong>.&nbsp;<br>Excellente autonomie et fluidité pour le travail, la création et la navigation.<br>Écran Retina 13\" offrant une qualité d’image exceptionnelle.&nbsp;</div>', '2025-07-08-a3b9e63c73c98f030abfbde7633115cdca6c9d10.jpg', 1000, 20, 0),
(19, 7, NULL, 'iPhone 16', 'iphone-16-1', '<div>iPhone élégant avec puce <strong>A15 Bionic</strong>, rapide et économe en énergie. <br>Appareil photo performant pour des photos nettes et vidéos en<strong> 4K</strong>.<br> Écran Retina lumineux et fluide, idéal pour tous les usages.</div>', '2025-07-08-721e91680ac15bad8a50b90dd3fcd250bb9e45b0.jpg', 950, 20, 0),
(20, 7, NULL, 'iPhone 16 Pro Max', 'iphone-16-pro-max-6', '<div>iPhone élégant avec puce <strong>A15</strong> Bionic, rapide et économe en énergie. <br>Appareil photo performant pour des photos nettes et vidéos en <strong>4K</strong>.&nbsp;<br>Écran Retina lumineux et fluide, idéal pour tous les usages.<br><br></div>', '2025-07-08-17e5384be2295aaa66784076429b2f86b92692df.jpg', 1200, 20, 0),
(21, 7, NULL, 'iPhone 15 Pro Max', 'iphone-15-pro-max-1', '<div>iPhone élégant avec puce <strong>A15</strong> Bionic, rapide et économe en énergie. <br>Appareil photo performant pour des photos nettes et vidéos en <strong>4K</strong>.&nbsp;<br>Écran Retina lumineux et fluide, idéal pour tous les usages.<br><br></div>', '2025-07-08-57a460710fc3e8098cfe9f6ab88bf15731b4d7a5.jpg', 1100, 20, 0),
(22, 3, NULL, 'Smartphone', 'smartphone-1', '<div>&nbsp;Smartphone polyvalent avec processeur rapide, <br>écran <strong>Full HD+</strong> et grande autonomie. <br>Appareil photo performant pour capturer chaque moment avec clarté. <br>Design moderne et interface fluide pour une expérience utilisateur optimale. <br><strong>Marque : </strong>SONY</div>', '2025-07-08-292708d0cd37abfe5c09c784f1741677e7b5c09f.jpg', 700, 20, 0),
(23, 3, NULL, 'Smartphone', 'smartphone-2', '<div>&nbsp;Smartphone polyvalent avec processeur rapide,<br>écran <strong>Full HD+</strong> et grande autonomie.<br>Appareil photo performant pour capturer chaque moment avec clarté.<br>Design moderne et interface fluide pour une expérience utilisateur optimale.<br><strong>Marque : </strong>SONY</div>', '2025-07-08-df22124300e485503d33b81f5dfc04186e1408da.jpg', 800, 20, 0),
(24, 3, NULL, 'Smartphone', 'smartphone-3', '<div>&nbsp;Smartphone polyvalent avec processeur rapide,<br>écran <strong>Full HD+</strong> et grande autonomie.<br>Appareil photo performant pour capturer chaque moment avec clarté.<br>Design moderne et interface fluide pour une expérience utilisateur optimale.<br><strong>Marque : </strong>SONY</div>', '2025-07-08-79ce75324bb26fd96b8070230205bad529b79f1b.jpg', 950, 20, 0),
(25, 3, NULL, 'Smartphone', 'smartphone-4', '<div>&nbsp;Smartphone polyvalent avec processeur rapide,<br>écran <strong>Full HD+</strong> et grande autonomie.<br>Appareil photo performant pour capturer chaque moment avec clarté.<br>Design moderne et interface fluide pour une expérience utilisateur optimale.<br><br></div>', '2025-07-08-35d25a3172986eefd00ddc41fb897b17744a26cd.jpg', 1000, 20, 0),
(26, 3, NULL, 'Smartphone', 'smartphone-5', '<div>&nbsp;Smartphone polyvalent avec processeur rapide,<br>écran <strong>Full HD+</strong> et grande autonomie.<br>Appareil photo performant pour capturer chaque moment avec clarté.<br>Design moderne et interface fluide pour une expérience utilisateur optimale.<br><strong>Marque : </strong>SONY</div>', '2025-07-08-df22124300e485503d33b81f5dfc04186e1408da.jpg', 650, 20, 0),
(27, 7, NULL, 'iPhone 15', 'iphone-15-1', '<div>&nbsp;iPhone élégant avec puce <strong>A15</strong> Bionic, rapide et économe en énergie. <br>Appareil photo performant pour des photos nettes et vidéos en <strong>4K</strong>.&nbsp;<br>Écran Retina lumineux et fluide, idéal pour tous les usages.&nbsp;</div>', '2025-07-08-748a499dfd2c63cb00dc6452a2ce390e4492eebf.jpg', 900, 20, 0),
(28, 6, NULL, 'iPad', 'ipad', '<div>iPad puissant avec puce <strong>A14</strong> Bionic, idéal pour le travail, les loisirs et la création. <br>Écran Retina <strong>10,9</strong>\" lumineux pour un confort visuel exceptionnel.&nbsp;<br>Compatible avec Apple Pencil et clavier pour une productivité maximale.<br><br></div>', '2025-07-08-644775af6ca898c1513a9f0ed5b422f29f915767.jpg', 500, 20, 0),
(29, 6, NULL, 'iPad', 'ipad-1', '<div>iPad puissant avec puce <strong>A14</strong> Bionic, idéal pour le travail, les loisirs et la création.<br>Écran Retina <strong>10,9</strong>\" lumineux pour un confort visuel exceptionnel.&nbsp;<br>Compatible avec Apple Pencil et clavier pour une productivité maximale.</div>', '2025-07-08-cd8e6f66174acc9d58109c4dfdd8504d7c4d1df7.jpg', 450, 20, 0),
(30, 6, NULL, 'iPad', 'ipad-2', '<div>iPad puissant avec puce <strong>A14</strong> Bionic, idéal pour le travail, les loisirs et la création.<br>Écran Retina <strong>10,9</strong>\" lumineux pour un confort visuel exceptionnel.&nbsp;<br>Compatible avec Apple Pencil et clavier pour une productivité maximale.</div>', '2025-07-08-d1d8572f77e71a5bd1afbf725a1e0e721c4af12d.jpg', 700, 20, 0),
(31, 6, NULL, 'iPad', 'ipad-23', '<div>iPad puissant avec puce <strong>A14</strong> Bionic, idéal pour le travail, les loisirs et la création.<br>Écran Retina <strong>10,9</strong>\" lumineux pour un confort visuel exceptionnel.&nbsp;<br>Compatible avec Apple Pencil et clavier pour une productivité maximale.</div>', '2025-07-08-13e8149201376d4419cfc22b46218ca7955bcd42.jpg', 470, 20, 0),
(32, 4, NULL, 'Montre connectée', 'montre-connectee-1', '<div>Montre connectée élégante avec suivi de la santé (rythme cardiaque, sommeil, activité).&nbsp;<br>Écran tactile intuitif et notifications en temps réel.&nbsp;<br>Autonomie longue durée et design compatible avec tous les styles.<br><br></div><div><br></div>', '2025-07-08-5fae4279a43d86b1332e9306abb587cbfcd6b331.jpg', 78, 20, 0),
(33, 4, NULL, 'Montre Multitâches', 'montre-connectee-2', '<div>Montre connectée élégante avec suivi de la santé (rythme cardiaque, sommeil, activité).&nbsp;<br>Écran tactile intuitif et notifications en temps réel.&nbsp;<br>Autonomie longue durée et design compatible avec tous les styles.</div>', '2025-07-08-fda8c1aaf3e5b85f5bdc72649b6df9b19a709f09.jpg', 200, 20, 0),
(34, 4, NULL, 'Montre connectée', 'montre-connectee-3', '<div>Montre connectée élégante avec suivi de la santé (rythme cardiaque, sommeil, activité).&nbsp;<br>Écran tactile intuitif et notifications en temps réel.&nbsp;<br>Autonomie longue durée et design compatible avec tous les styles.</div>', '2025-07-08-4e41e1a808170d1213568bb1ad56080d2a39745f.jpg', 70, 20, 0),
(35, 4, NULL, 'Montre connectée', 'montre-connectee-4', '<div>Montre connectée élégante avec suivi de la santé (rythme cardiaque, sommeil, activité).&nbsp;<br>Écran tactile intuitif et notifications en temps réel.&nbsp;<br>Autonomie longue durée et design compatible avec tous les styles.</div>', '2025-07-08-6b3714f8055a6d630ff98e5c37658a1be6bd2b05.jpg', 50, 20, 0),
(36, 4, NULL, 'Montre connectée', 'montre-connectee-5', '<div>Montre connectée élégante avec suivi de la santé (rythme cardiaque, sommeil, activité).&nbsp;<br>Écran tactile intuitif et notifications en temps réel.&nbsp;<br>Autonomie longue durée et design compatible avec tous les styles.</div>', '2025-07-08-dde101f574c69f21f02944bb7e751211722a6c5c.jpg', 80, 20, 0),
(37, 4, NULL, 'Montre connectée', 'montre-connectee-17', '<div>Montre connectée élégante avec suivi de la santé (rythme cardiaque, sommeil, activité).&nbsp;<br>Écran tactile intuitif et notifications en temps réel.&nbsp;<br>Autonomie longue durée et design compatible avec tous les styles.</div>', '2025-07-08-626b7034cdbf7df74157e850677815d69a75638c.jpg', 80, 20, 0),
(38, 4, NULL, 'Montre connectée', 'montre-connectee-20', '<div>Montre connectée élégante avec suivi de la santé (rythme cardiaque, sommeil, activité).&nbsp;<br>Écran tactile intuitif et notifications en temps réel.&nbsp;<br>Autonomie longue durée et design compatible avec tous les styles.</div>', '2025-07-08-d14845bb530c63a54265f14431e51e5327404c5f.jpg', 300, 20, 0);

-- --------------------------------------------------------

--
-- Structure de la table `profile`
--

CREATE TABLE `profile` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `review`
--

CREATE TABLE `review` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `note` int(11) DEFAULT NULL,
  `commentaire` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `stock`
--

CREATE TABLE `stock` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token_expire_at` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `is_verified` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `email`, `roles`, `password`, `firstname`, `lastname`, `token`, `token_expire_at`, `last_login_at`, `is_verified`) VALUES
(2, 'diawaraad97@gmail.com', '[\"ROLE_USER\", \"ROLE_ADMIN\"]', '$2y$13$ycAdq5yuxf9hIkkePl0pIOLREE3TGKQya8drNFeojaWcv5G1eH9/y', 'Adama', 'DIAWARA', '62e739a4541cb88663e472d364db6544a24e1a7ca83fdc9cb50a8010a6ef9b17', '2025-07-07 05:12:17', '2025-07-08 05:14:41', 1);

-- --------------------------------------------------------

--
-- Structure de la table `user_product`
--

CREATE TABLE `user_product` (
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `user_product`
--

INSERT INTO `user_product` (`user_id`, `product_id`) VALUES
(2, 5),
(2, 6),
(2, 24),
(2, 27);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `adresse`
--
ALTER TABLE `adresse`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_C35F0816A76ED395` (`user_id`);

--
-- Index pour la table `carrier`
--
ALTER TABLE `carrier`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `doctrine_migration_versions`
--
ALTER TABLE `doctrine_migration_versions`
  ADD PRIMARY KEY (`version`);

--
-- Index pour la table `header`
--
ALTER TABLE `header`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `messenger_messages`
--
ALTER TABLE `messenger_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_75EA56E0FB7336F0` (`queue_name`),
  ADD KEY `IDX_75EA56E0E3BD61CE` (`available_at`),
  ADD KEY `IDX_75EA56E016BA31DB` (`delivered_at`);

--
-- Index pour la table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_F5299398A76ED395` (`user_id`),
  ADD KEY `IDX_F529939821DFC797` (`carrier_id`);

--
-- Index pour la table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_ED896F46BFCDF877` (`my_order_id`);

--
-- Index pour la table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_D34A04AD12469DE2` (`category_id`),
  ADD KEY `IDX_D34A04AD4584665A` (`product_id`);

--
-- Index pour la table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_8157AA0FA76ED395` (`user_id`);

--
-- Index pour la table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_794381C6A76ED395` (`user_id`),
  ADD KEY `IDX_794381C64584665A` (`product_id`);

--
-- Index pour la table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_4B3656604584665A` (`product_id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_IDENTIFIER_EMAIL` (`email`);

--
-- Index pour la table `user_product`
--
ALTER TABLE `user_product`
  ADD PRIMARY KEY (`user_id`,`product_id`),
  ADD KEY `IDX_8B471AA7A76ED395` (`user_id`),
  ADD KEY `IDX_8B471AA74584665A` (`product_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `adresse`
--
ALTER TABLE `adresse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pour la table `carrier`
--
ALTER TABLE `carrier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `header`
--
ALTER TABLE `header`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `messenger_messages`
--
ALTER TABLE `messenger_messages`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pour la table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT pour la table `profile`
--
ALTER TABLE `profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `review`
--
ALTER TABLE `review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `adresse`
--
ALTER TABLE `adresse`
  ADD CONSTRAINT `FK_C35F0816A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Contraintes pour la table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `FK_F529939821DFC797` FOREIGN KEY (`carrier_id`) REFERENCES `carrier` (`id`),
  ADD CONSTRAINT `FK_F5299398A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Contraintes pour la table `order_detail`
--
ALTER TABLE `order_detail`
  ADD CONSTRAINT `FK_ED896F46BFCDF877` FOREIGN KEY (`my_order_id`) REFERENCES `order` (`id`);

--
-- Contraintes pour la table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `FK_D34A04AD12469DE2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  ADD CONSTRAINT `FK_D34A04AD4584665A` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`);

--
-- Contraintes pour la table `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `FK_8157AA0FA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Contraintes pour la table `review`
--
ALTER TABLE `review`
  ADD CONSTRAINT `FK_794381C64584665A` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  ADD CONSTRAINT `FK_794381C6A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Contraintes pour la table `stock`
--
ALTER TABLE `stock`
  ADD CONSTRAINT `FK_4B3656604584665A` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`);

--
-- Contraintes pour la table `user_product`
--
ALTER TABLE `user_product`
  ADD CONSTRAINT `FK_8B471AA74584665A` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_8B471AA7A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
